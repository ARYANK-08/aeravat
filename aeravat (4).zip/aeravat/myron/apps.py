from django.apps import AppConfig


class MyronConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "myron"
